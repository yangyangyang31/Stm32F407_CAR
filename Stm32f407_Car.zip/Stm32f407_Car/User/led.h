#ifndef __LED_H
#define __LED_H

#include "stm32f4xx.h"

//ÿ���Ƹ�ռһλ��������� & ����
#define 	LED0					((uint8_t)0x01)
#define 	LED1					((uint8_t)0x02)
#define 	LED2					((uint8_t)0x04)
#define 	LED3					((uint8_t)0x08)
#define   ALL_LED 			((uint8_t)0x0f)

//LED0     	GPIOF_9
#define GPIO_LED0_PIN     	GPIO_Pin_9
#define GPIO_LED0_PORT     	GPIOF

//LED1    	GPIOF_10
#define GPIO_LED1_PIN				GPIO_Pin_10
#define GPIO_LED1_PORT     	GPIOF

//FSMC_D10    GPIOE_13
#define GPIO_LED2_PIN				GPIO_Pin_13			//FSMC_D10
#define GPIO_LED2_PORT     	GPIOE

//FSMC_D11    GPIOE_14
#define GPIO_LED3_PIN				GPIO_Pin_14		//FSMC_D11
#define GPIO_LED3_PORT     	GPIOE

//ʱ��
#define GPIO_LED0_CLK  			RCC_AHB1Periph_GPIOF
#define GPIO_LED1_CLK  			RCC_AHB1Periph_GPIOF
#define GPIO_LED2_CLK  			RCC_AHB1Periph_GPIOE
#define GPIO_LED3_CLK  			RCC_AHB1Periph_GPIOE

void LED_GPIO_Config(uint8_t led);			//LEDС�Ƴ�ʼ��
void Control_Led(uint8_t led,FunctionalState NewState);				//LEDС�ƿ��ؿ���

#endif 

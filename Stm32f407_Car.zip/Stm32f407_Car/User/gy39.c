#include "gy39.h"
#include "usart.h"
#include "string.h"
#include "stdio.h"
#include "led_key.h"
unsigned char GY39_cmd1[]={0xA5,0x51,0xF6};//????
unsigned char GY39_cmd2[]={0xA5,0x52,0xF7};//????
unsigned char gy39_mode=0;
unsigned char recvbuf[32]={0};
unsigned char data_len=0;
unsigned char recv_ok=0;

void gy39_init(void)
{
	usart2_init(9600);
}


void gy39_start(unsigned char mode)
{
	gy39_mode = mode;
	if(gy39_mode == GUANGZHAO)
	{
		USART_SendDatas(USART2,GY39_cmd1, strlen((char*)GY39_cmd1));
	}
	else if(gy39_mode == OTHER)
	{
		USART_SendDatas(USART2,GY39_cmd2, strlen((char*)GY39_cmd2));
	}
}

void get_gy39_data(void)
{
	led_ctrl(1,0);
	unsigned int GZ,WD,QY,SD,HB;
	if(gy39_mode == GUANGZHAO)
	{
		GZ = recvbuf[4]<<24 | recvbuf[5]<<16 | recvbuf[6]<<8 | recvbuf[7];
		GZ = GZ/100;
		printf("GZ is %d\r\n",GZ);
	}
	else if(gy39_mode == OTHER)
	{
		WD = recvbuf[4]<<8 | recvbuf[5];
		WD = WD/100;
		QY = recvbuf[6]<<24 | recvbuf[7]<<16 | recvbuf[8]<<8 | recvbuf[9];
		QY = QY/100;
		SD = recvbuf[10]<<8 | recvbuf[11];
		SD = SD/100;
		HB = recvbuf[12]<<8 | recvbuf[13];
		printf("WD is %d,SD is %d,QY is %d,HB is %d\r\n",WD,SD,QY,HB);
		
		
	}

	recv_ok = 0;
	data_len = 0;
}

#ifndef GY39__H__
#define GY39__H__



void gy39_init(void);

void gy39_start(unsigned char mode);

void get_gy39_data(void);



#endif
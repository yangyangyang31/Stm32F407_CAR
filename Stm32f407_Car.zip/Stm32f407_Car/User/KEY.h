#ifndef __KEY_H
#define __KEY_H

#include "stm32f4xx.h"

/*
		KEY0   	PA0
		KEY1		PE2
		KEY2		PE3
		KEY3		PE4
*/

#define  	GPIO_KEY0_PIN						GPIO_Pin_0
#define  	GPIO_KEY0_PORT					GPIOA

#define  	GPIO_KEY1_PIN						GPIO_Pin_2
#define  	GPIO_KEY1_PORT					GPIOE

#define  	GPIO_KEY2_PIN						GPIO_Pin_3
#define  	GPIO_KEY2_PORT					GPIOE

#define  	GPIO_KEY3_PIN						GPIO_Pin_4
#define  	GPIO_KEY3_PORT					GPIOE

#define 	GPIO_KEY0_CLK						RCC_AHB1Periph_GPIOA
#define 	GPIO_KEY1_CLK						RCC_AHB1Periph_GPIOE
#define 	GPIO_KEY2_CLK						RCC_AHB1Periph_GPIOE
#define 	GPIO_KEY3_CLK						RCC_AHB1Periph_GPIOE

#define   Key_on				1
#define   Key_off				0

void KEY_GPIO_Config(void);				//������ʼ������
uint8_t Key_Down(GPIO_TypeDef* GPIOx , uint16_t GPIO_Pin);		//������⺯��


#endif

#ifndef __INFRARED_H
#define __INFRARED_H

#include "stm32f4xx.h"
#include "CAR.h"
#include "BEEP.h"
#include "delay.h"
#include "LED.h"

#define 	GPIO_L_I_PIN			GPIO_Pin_15
#define   GPIO_L_I_PORT			GPIOG

#define 	GPIO_R_I_PIN			GPIO_Pin_6
#define   GPIO_R_I_PORT			GPIOC

#define 	GPIO_L_I_CLK			RCC_AHB1Periph_GPIOG
#define 	GPIO_R_I_CLK			RCC_AHB1Periph_GPIOC

void IF_GPIO_Config(void);		//ѭ�������豸��ʼ��
void car_route(void);		//С��ѭ�� 

/*
	PG15   Camera   7
	PC6    Camera		8
*/



#endif

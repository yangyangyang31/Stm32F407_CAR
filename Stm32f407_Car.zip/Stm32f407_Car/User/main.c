   

#include "main.h"
#include <stdio.h>
#include "CAR.h"
#include "LED.h"
#include "KEY.h"
#include "BLUe.h"
  
int main(void) 
{
	LED_GPIO_Config(ALL_LED);
	CAR_GPIO_Config();
	BEEP_GPIO_Confing();
	BLUE_Init();
	while(1)
	{
		
	}

}

#include "CAR.h"

void CAR_PAUSE(void)	//ͣ��
{
	GPIO_SetBits(GPIO_R_U_PORT,GPIO_R_U_PIN);
	GPIO_SetBits(GPIO_R_B_PORT,GPIO_R_B_PIN);
	GPIO_SetBits(GPIO_L_U_PORT,GPIO_L_U_PIN);
	GPIO_SetBits(GPIO_L_B_PORT,GPIO_L_B_PIN);
}

void CAR_UP(void)		//ǰ��
{

	GPIO_SetBits(GPIO_L_B_PORT,GPIO_L_B_PIN);
	GPIO_SetBits(GPIO_R_B_PORT,GPIO_R_B_PIN);
	GPIO_ResetBits(GPIO_L_U_PORT,GPIO_L_U_PIN);
	GPIO_ResetBits(GPIO_R_U_PORT,GPIO_R_U_PIN);
}

void CAR_DOWN(void)		//����
{
	GPIO_ResetBits(GPIO_L_B_PORT,GPIO_L_B_PIN);
	GPIO_ResetBits(GPIO_R_B_PORT,GPIO_R_B_PIN);
	GPIO_SetBits(GPIO_R_U_PORT,GPIO_R_U_PIN);
	GPIO_SetBits(GPIO_L_U_PORT,GPIO_L_U_PIN);
}

void F_CAR_LEFT(void)  	//ǰ��ת
{
	GPIO_SetBits(GPIO_R_B_PORT,GPIO_R_B_PIN);
	GPIO_SetBits(GPIO_L_U_PORT,GPIO_L_U_PIN);
	GPIO_SetBits(GPIO_L_B_PORT,GPIO_L_B_PIN);
	GPIO_ResetBits(GPIO_R_U_PORT,GPIO_R_U_PIN);
}

void F_CAR_RIGHT(void)	//ǰ��ת
{
	GPIO_SetBits(GPIO_R_U_PORT,GPIO_R_U_PIN);
	GPIO_SetBits(GPIO_R_B_PORT,GPIO_R_B_PIN);
	GPIO_SetBits(GPIO_L_B_PORT,GPIO_L_B_PIN);
	GPIO_ResetBits(GPIO_L_U_PORT,GPIO_L_U_PIN);
}

void L_CAR_LEFT(void)		//����ת
{
	GPIO_SetBits(GPIO_L_U_PORT,GPIO_L_U_PIN);
	GPIO_SetBits(GPIO_L_B_PORT,GPIO_L_B_PIN);
	GPIO_SetBits(GPIO_R_U_PORT,GPIO_R_U_PIN);
	GPIO_ResetBits(GPIO_R_B_PORT,GPIO_R_B_PIN);
}

void L_CAR_RIGHT(void)		//����ת
{
	GPIO_SetBits(GPIO_R_B_PORT,GPIO_R_B_PIN);
	GPIO_SetBits(GPIO_L_U_PORT,GPIO_L_U_PIN);
	GPIO_SetBits(GPIO_R_U_PORT,GPIO_R_U_PIN);
	GPIO_ResetBits(GPIO_L_B_PORT,GPIO_L_B_PIN);
}


void CAR_GPIO_Config(void)//С����ʼ������
{
	//ʹ��ʱ��
	RCC_AHB1PeriphClockCmd(GPIO_R_B_CLK|GPIO_R_U_CLK|GPIO_L_B_CLK|GPIO_L_U_CLK,ENABLE);
	
	//�������
	GPIO_InitTypeDef G;
	
	G.GPIO_Mode=GPIO_Mode_OUT;
	G.GPIO_OType=GPIO_OType_PP;
	G.GPIO_Speed=	GPIO_Fast_Speed;
	
	G.GPIO_Pin = GPIO_R_U_PIN;
	GPIO_Init(GPIO_R_U_PORT,&G);
	
	G.GPIO_Pin = GPIO_R_B_PIN;
	GPIO_Init(GPIO_R_B_PORT,&G);
	
	G.GPIO_Pin = GPIO_L_U_PIN;
	GPIO_Init(GPIO_L_U_PORT,&G);
	
	G.GPIO_Pin = GPIO_L_B_PIN;
	GPIO_Init(GPIO_L_B_PORT,&G);
	
	GPIO_SetBits(GPIO_R_U_PORT,GPIO_R_U_PIN);
	GPIO_SetBits(GPIO_R_B_PORT,GPIO_R_B_PIN);
	GPIO_SetBits(GPIO_L_U_PORT,GPIO_L_U_PIN);
	GPIO_SetBits(GPIO_L_B_PORT,GPIO_L_B_PIN);
	
}

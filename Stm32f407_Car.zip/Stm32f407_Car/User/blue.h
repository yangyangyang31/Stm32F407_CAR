#ifndef 		__BLUE_H
#define 		__BLUE_H

#include "stm32f4xx.h"
#include "LED.h"
#include "stdio.h"
#include "CAR.h"
#include "BEEP.h"

#define 		GPIO_TX_PIN			GPIO_Pin_9
#define			GPIO_TX_PORT		GPIOA

#define 		GPIO_RX_PIN			GPIO_Pin_9
#define			GPIO_RX_PORT		GPIOA

#define 		GPIO_TX_CLK			RCC_AHB1Periph_GPIOA
#define 		GPIO_RX_CLK			RCC_AHB1Periph_GPIOA

void BLUE_Init(void);		//������ʼ��  

void USART1_IRQHandler(void);		//�����жϷ�����
int fputc(int c, FILE*stream);

#endif

